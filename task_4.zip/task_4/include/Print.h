#pragma once

class Print {
public:
	void printHello();
};
