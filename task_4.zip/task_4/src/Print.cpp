#include "Print.h"
#include <iostream>

void Print::printHello() {
    std::cout << "helloWorld" << std::endl;
}
