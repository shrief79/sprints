#include <stdint.h>
int64_t add( int32_t x, int32_t y);
int32_t sub( int32_t x, int32_t y);
int64_t mul( int32_t x, int32_t y);
int32_t square_root( int64_t x);
