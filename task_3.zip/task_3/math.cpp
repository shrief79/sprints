#include <math.h>
#include "math_calc.h"

int64_t add( int32_t x, int32_t y)
{
   return (int64_t )x + y ;
}

int32_t sub( int32_t x, int32_t y)
{
   return x - y ;
}

int64_t mul( int32_t x, int32_t y)
{
   return (int64_t )x * y ;
}

int32_t square_root( int64_t x)
{
   return (int32_t)sqrt(x) ;
}
