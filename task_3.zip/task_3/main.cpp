#include <stdio.h>
#include<iostream>
#include "math_calc.h"

int main()
{

     int32_t x = 7 ;
     int32_t y = 6 ;
     int64_t z =3025 ;
  	std::cout<< "the numbers is 7 and 6 "<<std::endl;
     printf("add = %ld\n", add(x,y));
     printf("sub = %d\n", sub(x,y));
     printf("mul = %ld\n", mul(x,y));
     printf("square_root of %ld  = %d\n",z, square_root( (int64_t)z));

     return 0;
}
